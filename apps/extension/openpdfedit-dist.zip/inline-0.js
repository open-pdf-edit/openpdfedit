
				{
					__sveltekit_lsszh0 = {
						base: ""
					};

					const element = document.currentScript.parentElement;

					Promise.all([
						import("/app/immutable/entry/start.Bg0wWKp-.js"),
						import("/app/immutable/entry/app.Xet_30HK.js")
					]).then(([kit, app]) => {
						kit.start(app, element);
					});
				}
			