
				{
					__sveltekit_1vzh90 = {
						base: ""
					};

					const element = document.currentScript.parentElement;

					Promise.all([
						import("/app/immutable/entry/start.qHtxo4m4.js"),
						import("/app/immutable/entry/app.Cgot1RIb.js")
					]).then(([kit, app]) => {
						kit.start(app, element);
					});
				}
			