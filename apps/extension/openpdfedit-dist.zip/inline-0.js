
				{
					__sveltekit_1cw4sfn = {
						base: ""
					};

					const element = document.currentScript.parentElement;

					Promise.all([
						import("/_app/immutable/entry/start.BW-fRWID.js"),
						import("/_app/immutable/entry/app.Bi1mHDom.js")
					]).then(([kit, app]) => {
						kit.start(app, element);
					});
				}
			