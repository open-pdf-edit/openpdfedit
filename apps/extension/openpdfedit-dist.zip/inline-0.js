
      if (location.hash.indexOf("tgWebApp") !== -1) {
        var tg = document.createElement("script");
        tg.src = "https://telegram.org/js/telegram-web-app.js";
        tg.onload = function () {
          dispatchEvent(new Event("openpdfedit:telegram-ready"));
        };
        document.head.appendChild(tg);
      }
    