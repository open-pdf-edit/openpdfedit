
				{
					__sveltekit_6n779v = {
						base: ""
					};

					const element = document.currentScript.parentElement;

					Promise.all([
						import("/app/immutable/entry/start.PjO_7DJm.js"),
						import("/app/immutable/entry/app.lb2yfkde.js")
					]).then(([kit, app]) => {
						kit.start(app, element);
					});
				}
			