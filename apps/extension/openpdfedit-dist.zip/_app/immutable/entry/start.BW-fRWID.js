import{l as o,a as r}from"../chunks/Dugahk_3.js";export{o as load_css,r as start};
