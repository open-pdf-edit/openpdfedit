import{l as o,a as r}from"../chunks/CCvv7B1L.js";export{o as load_css,r as start};
