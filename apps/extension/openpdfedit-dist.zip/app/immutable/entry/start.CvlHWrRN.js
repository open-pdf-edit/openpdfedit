import{a as r}from"../chunks/BVg7vtQa.js";import{y as t}from"../chunks/ccCQSdH_.js";export{t as load_css,r as start};
