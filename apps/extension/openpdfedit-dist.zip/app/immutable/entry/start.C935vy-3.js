import{l as o,a as r}from"../chunks/B1bBBA2x.js";export{o as load_css,r as start};
