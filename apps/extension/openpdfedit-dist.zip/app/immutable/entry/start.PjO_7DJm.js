import{l as o,a as r}from"../chunks/B19xlG6H.js";export{o as load_css,r as start};
