import{a as r}from"../chunks/1delw21W.js";import{y as t}from"../chunks/DG8XQaRM.js";export{t as load_css,r as start};
