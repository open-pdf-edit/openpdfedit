import{l as o,a as r}from"../chunks/9Uybf6Ia.js";export{o as load_css,r as start};
