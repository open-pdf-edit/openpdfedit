
				{
					__sveltekit_21yexp = {
						base: ""
					};

					const element = document.currentScript.parentElement;

					Promise.all([
						import("/app/immutable/entry/start.C935vy-3.js"),
						import("/app/immutable/entry/app.DtsDbINb.js")
					]).then(([kit, app]) => {
						kit.start(app, element);
					});
				}
			