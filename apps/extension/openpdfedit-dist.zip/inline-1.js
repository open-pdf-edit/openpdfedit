
				{
					__sveltekit_1qkh7hg = {
						base: ""
					};

					const element = document.currentScript.parentElement;

					Promise.all([
						import("/app/immutable/entry/start.BVoGHlD_.js"),
						import("/app/immutable/entry/app.CCx8jk1Z.js")
					]).then(([kit, app]) => {
						kit.start(app, element);
					});
				}
			