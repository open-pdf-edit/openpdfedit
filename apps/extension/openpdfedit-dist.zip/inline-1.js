
				{
					__sveltekit_1px4y9x = {
						base: ""
					};

					const element = document.currentScript.parentElement;

					Promise.all([
						import("/app/immutable/entry/start.CiiSDzKd.js"),
						import("/app/immutable/entry/app.BHd7KSWQ.js")
					]).then(([kit, app]) => {
						kit.start(app, element);
					});
				}
			