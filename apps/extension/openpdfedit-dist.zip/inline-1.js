
				{
					__sveltekit_21aja4 = {
						base: ""
					};

					const element = document.currentScript.parentElement;

					Promise.all([
						import("/app/immutable/entry/start.Cbw7RckB.js"),
						import("/app/immutable/entry/app.C1WUQnKr.js")
					]).then(([kit, app]) => {
						kit.start(app, element);
					});
				}
			