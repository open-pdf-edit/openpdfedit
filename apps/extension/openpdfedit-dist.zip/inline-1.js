
				{
					__sveltekit_1vbmdv = {
						base: ""
					};

					const element = document.currentScript.parentElement;

					Promise.all([
						import("/app/immutable/entry/start.DvlG4amJ.js"),
						import("/app/immutable/entry/app.ZkihbnaZ.js")
					]).then(([kit, app]) => {
						kit.start(app, element);
					});
				}
			