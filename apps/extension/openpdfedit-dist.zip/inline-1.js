
				{
					__sveltekit_1qkh7hg = {
						base: ""
					};

					const element = document.currentScript.parentElement;

					Promise.all([
						import("/app/immutable/entry/start.CvlHWrRN.js"),
						import("/app/immutable/entry/app.Qvn6G1IZ.js")
					]).then(([kit, app]) => {
						kit.start(app, element);
					});
				}
			